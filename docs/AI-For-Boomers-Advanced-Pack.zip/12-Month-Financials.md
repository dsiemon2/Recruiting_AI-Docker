# 12-Month Financial Projection
- Avg price: $15/mo
- Users month 12: 10,000
- ARR run rate: ~$1.8M
- Gross margin target: 75%
