# Figma Wireframe Specs
Boomer App:
- Home (Today)
- Medications
- Appointments
- Emergency

Caregiver App:
- Dashboard
- Alerts
- Weekly Summary
