# Go-To-Market Strategy

Boomers:
- App stores
- Community groups
- Simplicity messaging

Caregivers:
- Referrals
- Peace-of-mind messaging
