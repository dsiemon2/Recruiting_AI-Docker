# SOC2 Gap Analysis Worksheet

## Security
- RBAC implemented? [ ]
- MFA enabled? [ ]
- Audit logs retained? [ ]

## Availability
- Monitoring in place? [ ]
- Incident response plan? [ ]

## Confidentiality
- Encryption at rest? [ ]
- Encryption in transit? [ ]

## Next Actions
- Assign control owners
- Collect evidence
