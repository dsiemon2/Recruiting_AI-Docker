# Enterprise Pricing & Contract Redlines

## Pricing Adjustments
- Volume discounts at 100+ users
- Annual prepay discounts (10–20%)

## Contract Redlines
- Data ownership explicitly customer-owned
- No medical services clause
- Liability cap = 12 months fees
- Pilot termination flexibility
