# DRAFT / ARCHIVAL
## AI Recruiting Assistant – Teams & Zoom Integration Guide

This document represents an early integration-focused exploration.
It predates the formal PRD and architecture documents.

Key Topics:
- Twilio + Teams + Zoom feasibility
- Scheduling vs in-meeting assistant distinction
- Platform limitations and risks
