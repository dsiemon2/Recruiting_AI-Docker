# PRD (Canonical)

Authoritative Product Requirements Document.
