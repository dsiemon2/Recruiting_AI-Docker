# Repo Skeleton (Canonical)

Authoritative repository layout.
