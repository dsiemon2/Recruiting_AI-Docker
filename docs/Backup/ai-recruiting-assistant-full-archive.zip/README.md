# AI Recruiting Assistant – Full Documentation Archive

Generated on 2025-12-15.

This archive contains:
- Canonical product documents (current source of truth)
- Archival draft documents recreated from earlier session stages

Draft files are clearly labeled **DRAFT / ARCHIVAL** and preserved for historical context.
