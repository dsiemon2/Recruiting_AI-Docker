# DRAFT / ARCHIVAL
## Early Architecture Sketch

This document reflects early architectural thinking before normalization
into the final Architecture.md.
