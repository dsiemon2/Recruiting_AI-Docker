# Investor Pitch (Canonical)

Authoritative investor narrative.
