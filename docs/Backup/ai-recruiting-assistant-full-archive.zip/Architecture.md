# Architecture (Canonical)

Authoritative technical architecture.
