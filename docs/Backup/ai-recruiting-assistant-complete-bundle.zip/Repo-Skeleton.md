# Repository Skeleton

Directory layout and adapter structure.
