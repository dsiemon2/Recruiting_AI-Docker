# Pilot Statement of Work (SOW)

## Pilot Scope
- 50–100 users
- Caregiver access enabled

## Duration
90 days

## Success Metrics
- Reminder success rate
- Caregiver satisfaction

## Fees
Pilot fee or waived for evaluation.
