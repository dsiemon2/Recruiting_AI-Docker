# Master Services Agreement (MSA) – Template (Summary)

## Parties
Provider: AI for Boomers, Inc.
Client: ____________________

## Scope
Personal organization and reminder services.

## Data Ownership
Client data remains client-owned.

## Privacy & Security
Reasonable safeguards; no clinical services.

## Fees
As defined in applicable SOW.

## Liability
Standard SaaS limitation of liability.

## Termination
30-day written notice.
