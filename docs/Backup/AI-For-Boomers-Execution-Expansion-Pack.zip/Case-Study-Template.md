# Customer Case Study Template

## Customer Profile
Organization type, size

## Challenge
What wasn’t working

## Solution
How AI for Boomers was used

## Results
- Missed reminders reduced
- Caregiver satisfaction improved

## Quote
Customer testimonial
