# Compliance Positioning (HIPAA-Adjacent)

AI for Boomers is not a clinical system.

- No diagnosis
- No treatment advice
- User-controlled data
- Explicit consent
- Architecture supports HIPAA alignment if required
