# UX Wireframe Flows – Sharing

## Family Reassurance
Event → Prompt → Preview → Confirm → Send

## Referral
Value Moment → Prompt → Channel → Share

## Caregiver Alert
Missed Event → Escalation → Notify Caregiver
