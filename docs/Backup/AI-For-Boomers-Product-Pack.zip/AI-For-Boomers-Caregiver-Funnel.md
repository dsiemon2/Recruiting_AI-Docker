# Caregiver Onboarding Funnel

1. Invite caregiver
2. Frame trust and reassurance
3. View-only access
4. First reassurance alert
5. Weekly summaries
6. Advocacy and referrals
