# Pricing & Margin Model

## Plans
Free – $0
Plus – $9.99/mo
Family – $19.99/mo
Premium – $29.99/mo

## Estimated Gross Margin
- AI + Notifications: ~$3/user
- Margin target: 70–80%
