# PRD → Epics & Jira Stories

## Epic 1: Core Assistant
- Story: Voice command recognition
- Story: CRUD appointments
- Story: CRUD medications
- Story: Notes via dictation

## Epic 2: Notifications
- Story: Push reminders
- Story: SMS fallback
- Story: Escalation rules

## Epic 3: Caregiver Experience
- Story: Invite caregiver
- Story: View-only dashboard
- Story: Escalation alerts

## Epic 4: Social Sharing
- Story: Family reassurance sharing
- Story: Referral sharing

## Epic 5: Billing
- Story: Subscription plans
- Story: Payment retries
