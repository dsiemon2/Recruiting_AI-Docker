# Wireframes (Screen-by-Screen)

## Boomer App
1. Home (Today)
2. Medications
3. Appointments
4. Contacts
5. Notes
6. Emergency Button

## Caregiver App
1. Dashboard
2. Alerts
3. Weekly Summary
4. Permissions
